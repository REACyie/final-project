<?php
/**
 *右侧公用文件
 */
?>

<div class="col-sm-3" role="complementary">
    <nav class="vnav-wrapper">
        <ul>
            <li class="active"><a href="qiandao.php">签到记录</a></li>
            <li class="active"><a href="xiaofei.php">消费记录</a></li>
        </ul>
    </nav>
</div>